
# Panel Comercial - Streamlit App

Esta aplicación permite cargar y visualizar archivos Excel relacionados con promociones, compensaciones, vinilos, etc.
- Filtra por zonas y precios
- Accede a carpetas especiales (como Segundo canal < 7 €)
- Subida de archivos y conexión con Google Drive
